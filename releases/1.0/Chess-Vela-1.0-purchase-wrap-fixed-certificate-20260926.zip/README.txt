Chess Vela 1.0.0 Production Signing Package
============================================

Files:
- private.pem: retained only in the private signing repository; never publish it.
- certificate.pem: matching self-signed X.509 certificate.

Certificate fingerprint (SHA-256):
FB:34:79:6A:88:2B:DE:0F:FE:80:23:6E:87:25:81:FD:FA:32:10:40:66:D4:19:92:ED:2C:12:DD:BC:7D:04:5A

This is a project-generated signing identity, not an Xiaomi/AIoT official certificate.
It was accepted by AIoT Toolkit 2.0.4 production mode and used to create:
com.xykadi.chess.release.1.0.0.rpk

To reproduce the production build, place these files at:
project-root/sign/private.pem
project-root/sign/certificate.pem
then run:
npm ci
npm run release
