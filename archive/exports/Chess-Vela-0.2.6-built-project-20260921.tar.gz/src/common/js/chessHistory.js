const HISTORY_KEY = 'CHESS_GAME_HISTORY';
const MAX_HISTORY = 50;
const MIN_MOVES_TO_SAVE = 8;

function loadAll(success, fail) {
  try {
    require('@system.storage').get({
      key: HISTORY_KEY,
      success: function (r) {
        try {
          const raw = r && r.data !== undefined ? r.data : r;
          if (!raw) { success([]); return; }
          const arr = typeof raw === 'string' ? JSON.parse(raw) : raw;
          success(Array.isArray(arr) ? arr : []);
        } catch (e) { success([]); }
      },
      fail: function () { success([]); }
    });
  } catch (e) { success([]); }
}

function saveAll(list, success, fail) {
  try {
    require('@system.storage').set({
      key: HISTORY_KEY,
      value: JSON.stringify(list || []),
      success: success || function () {},
      fail: fail || function () {}
    });
  } catch (e) { if (fail) fail(e); }
}

function addGame(gameRecord, done) {
  if (!gameRecord || (gameRecord.moveCount || 0) < MIN_MOVES_TO_SAVE) {
    if (done) done(false);
    return;
  }
  loadAll(function (list) {
    const arr = list || [];
    arr.unshift(gameRecord);
    while (arr.length > MAX_HISTORY) arr.pop();
    saveAll(arr, function () { if (done) done(true); });
  });
}

function getGame(id, done) {
  loadAll(function (list) {
    for (let i = 0; i < list.length; i++) {
      if (String(list[i].id) === String(id)) { done(list[i]); return; }
    }
    done(null);
  });
}

function deleteGame(id, done) {
  loadAll(function (list) {
    const out = [];
    for (let i = 0; i < list.length; i++) {
      if (String(list[i].id) !== String(id)) out.push(list[i]);
    }
    saveAll(out, function () { if (done) done(true); });
  });
}

function clearAll(done) {
  saveAll([], function () { if (done) done(true); });
}

function newGameId() {
  return 'g_' + Date.now().toString(36) + '_' + Math.floor(Math.random() * 1000).toString(36);
}

function formatDate(ts) {
  const d = new Date(ts || Date.now());
  const y = d.getFullYear();
  const m = (d.getMonth() + 1 < 10 ? '0' : '') + (d.getMonth() + 1);
  const day = (d.getDate() < 10 ? '0' : '') + d.getDate();
  const hh = (d.getHours() < 10 ? '0' : '') + d.getHours();
  const mm = (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
  return y + '-' + m + '-' + day + ' ' + hh + ':' + mm;
}

module.exports = {
  HISTORY_KEY: HISTORY_KEY,
  MAX_HISTORY: MAX_HISTORY,
  MIN_MOVES_TO_SAVE: MIN_MOVES_TO_SAVE,
  loadAll: loadAll,
  saveAll: saveAll,
  addGame: addGame,
  getGame: getGame,
  deleteGame: deleteGame,
  clearAll: clearAll,
  newGameId: newGameId,
  formatDate: formatDate
};
