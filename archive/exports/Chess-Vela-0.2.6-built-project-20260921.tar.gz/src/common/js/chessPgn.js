const FILES = 'abcdefgh';
const RANKS = '87654321';
const PIECE_NAMES = { K: 'K', Q: 'Q', R: 'R', B: 'B', N: 'N', P: '' };

function sqToAlg(i) {
  const col = i % 8;
  const row = Math.floor(i / 8);
  return FILES[col] + RANKS[row];
}

function algToSq(alg) {
  const col = FILES.indexOf(alg[0]);
  const row = RANKS.indexOf(alg[1]);
  if (col < 0 || row < 0) return -1;
  return row * 8 + col;
}

function findPiece(board, color, type, to, fromHint) {
  const prefix = color === 'white' ? 'w' : 'b';
  const target = prefix + type;
  const matches = [];
  for (let i = 0; i < 64; i++) {
    if (board[i] === target) matches.push(i);
  }
  if (matches.length === 1) return matches[0];
  if (fromHint) {
    const colHint = FILES.indexOf(fromHint[0]);
    const rowHint = RANKS.indexOf(fromHint[1]);
    for (let n = 0; n < matches.length; n++) {
      const m = matches[n];
      const col = m % 8, row = Math.floor(m / 8);
      if (colHint >= 0 && col !== colHint) continue;
      if (rowHint >= 0 && row !== rowHint) continue;
      return m;
    }
  }
  return -1;
}

function moveToSAN(board, from, to, promotion, captured, isCheck, isMate, castling) {
  const p = board[to] || (promotion ? (board[from] ? board[from][0] + promotion : '') : '');
  if (!p) return sqToAlg(from) + sqToAlg(to);
  const color = p[0];
  const type = p[1];

  if (type === 'K' && Math.abs(to - from) === 2) {
    return to > from ? 'O-O' : 'O-O-O';
  }

  let san = '';
  if (type !== 'P') {
    san += type;
    const prefix = color + type;
    const matches = [];
    for (let i = 0; i < 64; i++) {
      if (i !== from && board[i] === prefix) matches.push(i);
    }
    if (matches.length) {
      const fromCol = FILES[from % 8];
      const fromRow = RANKS[Math.floor(from / 8)];
      let colClash = false, rowClash = false;
      for (let n = 0; n < matches.length; n++) {
        if (matches[n] % 8 === from % 8) colClash = true;
        if (Math.floor(matches[n] / 8) === Math.floor(from / 8)) rowClash = true;
      }
      if (!colClash) san += fromCol;
      else if (!rowClash) san += fromRow;
      else san += fromCol + fromRow;
    }
  }
  if (captured) {
    if (type === 'P') san += FILES[from % 8];
    san += 'x';
  }
  san += sqToAlg(to);
  if (promotion) san += '=' + promotion;
  if (isMate) san += '#';
  else if (isCheck) san += '+';
  return san;
}

function historyToPGN(history, meta) {
  const lines = [];
  if (meta) {
    if (meta.event) lines.push('[Event "' + meta.event + '"]');
    if (meta.site) lines.push('[Site "' + meta.site + '"]');
    if (meta.date) lines.push('[Date "' + meta.date + '"]');
    if (meta.white) lines.push('[White "' + meta.white + '"]');
    if (meta.black) lines.push('[Black "' + meta.black + '"]');
    if (meta.result) lines.push('[Result "' + meta.result + '"]');
    if (meta.timeControl) lines.push('[TimeControl "' + meta.timeControl + '"]');
  }
  lines.push('');
  let row = '';
  for (let i = 0; i < history.length; i++) {
    const num = Math.floor(i / 2) + 1;
    if (i % 2 === 0) {
      if (row) lines.push(row);
      row = num + '. ' + history[i];
    } else {
      row += ' ' + history[i];
    }
  }
  if (row) lines.push(row);
  if (meta && meta.result) lines.push(meta.result);
  return lines.join('\n');
}

function pgnToMoves(pgn) {
  const lines = pgn.split(/\r?\n/);
  const moves = [];
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].trim();
    if (!line || line[0] === '[') continue;
    line = line.replace(/\d+\.\s*/g, ' ').replace(/\{[^}]*\}/g, '').replace(/\$[0-9]+/g, '');
    const parts = line.split(/\s+/).filter(Boolean);
    for (let n = 0; n < parts.length; n++) {
      const t = parts[n];
      if (t === '1-0' || t === '0-1' || t === '1/2-1/2' || t === '*') continue;
      moves.push(t);
    }
  }
  return moves;
}

function parseSAN(board, san, turn, castlingRights, lastMove) {
  let s = (san || '').trim();
  if (!s) return null;
  s = s.replace(/[+#!?]/g, '');
  const color = turn;
  const opp = color === 'white' ? 'black' : 'white';

  if (s === 'O-O' || s === '0-0') {
    const kingSq = color === 'white' ? 60 : 4;
    return { from: kingSq, to: kingSq + 2, promotion: null, castling: 'K' };
  }
  if (s === 'O-O-O' || s === '0-0-0') {
    const kingSq = color === 'white' ? 60 : 4;
    return { from: kingSq, to: kingSq - 2, promotion: null, castling: 'Q' };
  }

  let promotion = null;
  const eq = s.indexOf('=');
  if (eq >= 0) {
    promotion = s[eq + 1];
    s = s.substring(0, eq);
  }

  let type = 'P';
  let fromHint = '';
  let capture = false;
  let target;

  if (s[0] >= 'A' && s[0] <= 'Z') {
    type = s[0];
    s = s.substring(1);
  }

  const capIdx = s.indexOf('x');
  if (capIdx >= 0) {
    capture = true;
    if (capIdx > 0) fromHint = s.substring(0, capIdx);
    target = s.substring(capIdx + 1);
  } else {
    if (s.length >= 2 && s[s.length - 1] >= '1' && s[s.length - 1] <= '8' && FILES.indexOf(s[s.length - 2]) >= 0) {
      target = s.substring(s.length - 2);
      fromHint = s.substring(0, s.length - 2);
    } else {
      target = s;
    }
  }

  if (!target || target.length < 2) return null;
  const to = algToSq(target);
  if (to < 0) return null;
  const from = findPiece(board, color, type, to, fromHint);
  if (from < 0) return null;
  return { from: from, to: to, promotion: promotion, castling: null };
}

module.exports = {
  sqToAlg: sqToAlg,
  algToSq: algToSq,
  moveToSAN: moveToSAN,
  historyToPGN: historyToPGN,
  pgnToMoves: pgnToMoves,
  parseSAN: parseSAN
};
