# Chess for Xiaomi Band 9 Vela

这是运行在 Xiaomi Band 9 Vela 系统上的离线 JS 快应用项目。当前主线源码为 **Chess 1.0.0**，包名为 `com.xykadi.chess`，开发者为 `XYKadi`。

## 从哪里开始

新 Agent 应先阅读：

1. [`docs/AGENT_HANDOFF.md`](docs/AGENT_HANDOFF.md)：仓库原有技术交接资料。
2. [`docs/AGENT_HANDOFF_20260925.md`](docs/AGENT_HANDOFF_20260925.md)：当前 1.0.0 源码、页面结构、关于页状态和下一步真机验收要求。
3. [`docs/RELEASE_CATALOG.md`](docs/RELEASE_CATALOG.md)：当前版本和历史归档索引。

## 目录分类

| 目录 | 内容 |
|---|---|
| `src/` | 当前可构建的 1.0.0 源码、页面、manifest 和图片资源。 |
| `tools/` | 当前版本使用的专项校验脚本，以及历史兼容性校验脚本。 |
| `archive/` | 历史源码、诊断资料、旧 RPK 和版本归档包。历史源码已压缩保存，不作为当前构建输入。 |
| `archive/releases/` | 已生成的版本 RPK、源码归档和 SHA-256 文件。 |
| `archive/dist/` | 仓库历史上保留的 0.2.x RPK 构建产物。 |
| `docs/` | 当前交接文档和版本索引。 |

## 当前源码构建

```bash
npm ci --cache .npm-cache
node tools/verify_about_release.js
node tools/verify_pause_resume.js
npm run build
```

构建入口在 `package.json` 中定义为 `aiot build`。当前版本使用 `aiot-toolkit` 2.0.4，设计宽度为 192dp，设备类型为 `watch`。

## 当前 1.0.0 交付物

最新正式模式构建发布在 [`Chess 1.0.0 — Purchase Page Wrap Fix (Debug)`](https://github.com/XYkadicloud/Chess-For-Xiaomi-Band/releases/tag/v1.0.0-purchase-wrap-release)，包含 Debug RPK、完整源码归档和 SHA-256 校验文件。生产模式构建已完成；私钥未放入公开仓库，单独保存在私有签名仓库。主线 `src/` 与该源码归档保持同步。

当前版本已经包含独立关于页、开发者头像、应用图标、爱发电二维码、购买提示页、首次启动购买状态和二维码大图页。购买页文字采用固定宽度多行换行，关于页提供“前往付款”入口。页面的真机滚动和视觉尺寸仍应在 Band 9 上进行最终验收，详细要求见当前交接文档。

## 历史版本

历史源码和诊断资料已压缩保存于 [`archive/history-20260925.tar.gz`](archive/history-20260925.tar.gz) 和 [`archive/diagnostics-20260925.tar.gz`](archive/diagnostics-20260925.tar.gz)。历史 RPK 位于 [`archive/dist/`](archive/dist/)，版本归档包位于 [`archive/exports/`](archive/exports/)。这些资料用于回退、对比和问题定位，不应直接覆盖当前 `src/`。

## Git 约定

当前可构建源码保留在仓库根目录的 `src/`，历史资料统一放在 `archive/`，交付物放在 `archive/releases/`。修改当前版本时应先备份 `src/`，完成专项校验后再提交。不要把 `node_modules/`、`build/`、临时目录或日志提交到仓库。

## 开源许可证

本项目源代码采用 **GNU General Public License v3.0（GPL-3.0）** 发布，具体条款见仓库根目录的 [`LICENSE`](LICENSE) 文件。

GPL-3.0 要求分发本项目或其衍生作品时遵守相同许可证的再发布义务，并保留版权和许可证声明。`archive/releases/` 中的 RPK 属于由本项目构建的发布产物；发布或再分发时，也应同时遵守 GPL-3.0 以及其中包含的第三方代码和资源所适用的额外条款。

本许可证说明不代表对 Xiaomi、Vela、Xiaomi Band、AstroBox 或其他第三方商标、平台、服务和资源授予额外权利。
## References

[1]: https://github.com/XYkadicloud/Chess-For-Xiaomi-Band "Chess for Xiaomi Band build repository"

[2]: https://github.com/XYkadicloud/Chess-for-miband9-use-agent "Chess for Mi Band 9 agent handoff repository"

## Xiaomi Smart Band 9 Pro 适配

本分支针对 Xiaomi Smart Band 9 Pro 的官方硬件规格进行了静态适配：

- 显示屏：1.74 英寸 AMOLED 触摸屏
- 分辨率：**336×480 像素**
- 亮度：最高 1200 nits，支持自动亮度
- 盖板：2.5D 强化玻璃
- 外壳：铝合金中框、高强度纤维聚合物
- 传感器：加速度计、陀螺仪、电子罗盘、光学心率/血氧、环境光传感器
- 定位与连接：独立 GNSS，支持 BeiDou、GPS、GLONASS、Galileo、QZSS；Bluetooth 5.4
- 防水：5ATM
- 电池：350mAh，磁吸充电，官方约 75 分钟充满
- 续航：典型使用最长约 21 天；AOD 约 10 天；重负载约 8 天
- 线性马达：支持触觉反馈
- 官方兼容系统：Android 8.0+ / iOS 12.0+

适配实现重点：`manifest.json` 使用 `designWidth: 336`，所有页面画布使用 `336dp × 480dp`；棋盘在 336dp 宽视口内居中，触摸拖动边界同步使用 336dp；设备类型仍使用 Vela 快应用要求的 `watch`，没有凭空添加 `band` 类型。该离线棋类应用不调用 GNSS、心率、血氧等硬件能力，因此这些硬件不需要额外 API 适配。

官方依据：
- [Xiaomi Smart Band 9 Pro Global Specs](https://www.mi.com/global/product/xiaomi-smart-band-9-pro/specs/)
- [Xiaomi Smart Band 9 Pro Global Product Page](https://www.mi.com/global/product/xiaomi-smart-band-9-pro/)
- [Xiaomi Smart Band 9 Pro FAQ](https://www.mi.com/global/support/faq/details/KA-512990/)
